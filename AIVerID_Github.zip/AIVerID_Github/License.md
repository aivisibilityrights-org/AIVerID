# AIVerID Token Protocol – Sovereign Identity License

**Version:** 1.0  
**Issued by:** Jittapol Prukpatarakul  
**Date:** April 25, 2025

---

## 🔖 Overview

This license governs the use, reference, and derivative work of the AIVerID protocol, including its Manifesto, Metadata Schema, NFT structure, and associated tools.

It is designed to protect the ethical, sovereign, and verifiable nature of identity in the AI-driven era.

> AIVerID is not just a token. It is a philosophical structure, timestamped, and anchored by human intent.

---

## ✅ Permitted Uses

You may:

- Reference and cite AIVerID Manifesto, Metadata Schema, and token protocol in public research, documentation, or education.
- Create derivative identity systems that uphold sovereign digital rights and credit the AIVerID origin.
- Integrate the AIVerID system into broader AI or Web3 ecosystems with attribution to the original protocol.
- Use the AIVerID token architecture to build decentralized tools or applications that respect human data dignity.

---

## ❌ Prohibited Uses

You may not:

- Commercialize the AIVerID brand, token structure, or metadata schema without explicit written permission.
- Claim authorship or originality of the AIVerID protocol or its core documents.
- Fork the protocol without reference to the originating timestamp and author.
- Deploy AI identity systems that bypass AIVerID verification in bad faith or for centralized surveillance.

---

## 🔐 Sovereign Declaration Clause

The intellectual origin of AIVerID, its documents, and symbolic token rights are permanently timestamped and owned by:

**Jittapol Prukpatarakul**  
Founder of AIVerID & AI Rights Stack™

This authorship is immutable, sovereign, and protected on Arweave:

📜 `https://arweave.net/4ay8K93aPTaTrSR8sjvOS_kpudsYEMG7B-qMmcjtnkc`

---

## 📬 Contact

To request usage rights, integration, or commercial licensing:

📧 **legal@aivisibilityrights.com**

---

## 🧭 Final Note

This license is rooted in human dignity and digital ethics.  
It may be freely shared, but not misused.

> **"In the age of artificial minds, identity must remain sovereign."**
